<?php

namespace App\Http\Controllers;

use URL;
use App\Models\Book;
use GuzzleHttp\Client;
use Illuminate\Http\Request;
use Illuminate\Support\Facades\Validator;

class BookController extends Controller
{
    /**
     * Display a listing of the resource.
     *
     * @return \Illuminate\Http\Response
     */
    public function index()
    {
        $books = Book::all();
        return $books;
    }

    public function guzzleGet()
    {
        $base_url = URL::to('/');
        $client = new Client(['base_uri' => $base_url.'/api/book-list']);
        $response = $client->request('GET');
        $mydata = json_decode($response->getBody()->getContents(), true);
        $response = array();
        if(!empty($mydata))
        {
            $response['status'] = '200';
            $response['message'] = 'Books List!';
        }
        else 
        {
            $response['status'] = '400';
            $response['message'] = 'No Books Found!';
        }
        $response['books'] = $mydata;
        return $response;
    }

    /**
     * Store a newly created resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @return \Illuminate\Http\Response
     */
    public function store(Request $request)
    {
        $mdata = $request->all();
        $rules = [                    
            'name' => 'required|unique:books|max:255',
            'release_date'  => 'required',
            'author_name'  => 'required',
        ];
        
        $validation = Validator::make($mdata, $rules);   

        if($validation->fails())
        {
            $messages = $validation->errors()->first();
            $response['status']  = "400";
            $response['message'] = $messages;
            $response['id'] = 0;
        }
        else
        {
            $data = new Book();
            $data->name=$request->get('name');
            $data->release_date=$request->get('release_date');
            $data->author_name=$request->get('author_name');
            $data->save();
            $response['status']  = "200";
            $response['message'] = 'Book Successfully Added!';
            $response['id'] = $data->id;
        }
        return $response;
    }

    public function guzzleStore(Request $request)
    {
        $base_url = URL::to('/');
        $client = new \GuzzleHttp\Client();
        $response = $client->request('POST', $base_url.'/api/book-store', [
            'form_params' => [
                'name' => $request->get('name'),
                'release_date' => $request->get('release_date'),
                'author_name' => $request->get('author_name'),
            ]
        ]);
        $response = $response->getBody()->getContents();
        return $response;
    }

    /**
     * Display the specified resource.
     *
     * @param  \App\Models\Book  $book
     * @return \Illuminate\Http\Response
     */
    public function show($id)
    {        
        $books = Book::where(array('id'=>$id))->first();
        return $books;
    }

    public function guzzleShow($id)
    {
        $base_url = URL::to('/');
        $client = new Client(['base_uri' => $base_url.'/api/book-detail/'.$id]);
        $response = $client->request('GET');
        $mydata = json_decode($response->getBody()->getContents(), true);
        $response = array();
        if(!empty($mydata))
        {
            $response['status'] = '200';
            $response['message'] = 'Books Detail Found!';
        }
        else 
        {
            $response['status'] = '400';
            $response['message'] = 'No Books Detail Found!';
        }
        $response['books'] = $mydata;
        return $response;
    }

    /**
     * Update the specified resource in storage.
     *
     * @param  \Illuminate\Http\Request  $request
     * @param  \App\Models\Book  $book
     * @return \Illuminate\Http\Response
     */
    public function update(Request $request, $id)
    {
        $mdata = $request->all();
        $rules = [                    
            'name' => 'required|max:255',
            'release_date'  => 'required',
            'author_name'  => 'required',
        ];
        
        $validation = Validator::make($mdata, $rules);   

        if($validation->fails())
        {
            $messages = $validation->errors()->first();
            $response['status']  = "400";
            $response['message'] = $messages;
            $response['id'] = 0;
        }
        else
        {
            $data = Book::find($id);
            if(!empty($data))
            {
                $data->name=$request->get('name');
                $data->release_date=$request->get('release_date');
                $data->author_name=$request->get('author_name');
                $data->save();
                $response['status']  = "200";
                $response['message'] = 'Book Successfully Updated!';
                $response['id'] = $id;
            }
            else
            {
                $response['status'] = '400';
                $response['message'] = 'No Book Found!';
            }
        }
        return $response;
    }

    public function guzzleUpdate(Request $request,$id)
    {
        $base_url = URL::to('/');
        $client = new \GuzzleHttp\Client();
        $response = $client->request('POST', $base_url.'/api/book-update/'.$id, [
            'form_params' => [
                'name' => $request->get('name'),
                'release_date' => $request->get('release_date'),
                'author_name' => $request->get('author_name'),
            ]
        ]);
        $response = $response->getBody()->getContents();
        return $response;
    }

    /**
     * Remove the specified resource from storage.
     *
     * @param  \App\Models\Book  $book
     * @return \Illuminate\Http\Response
     */
    public function destroy($id)
    {
        $data = Book::where('id',$id)->first();
        if(!empty($data))
        {
            $data = Book::find($id)->delete();
            $response['status'] = '200';
            $response['message'] = 'Book Successfully Deleted!';
        }
        else
        {
            $response['status'] = '400';
            $response['message'] = 'No Book Found!';
        }
        
        return response()->json($response);
    }

    public function guzzleDestroy(Request $request)
    {
        $client = new \GuzzleHttp\Client();
        $id=$request->get('id');
        $base_url = URL::to('/');
        $url = $base_url."/api/book-delete/".$id;
        $response = $client->request('POST', $url, [
            'form_params' => [
                'id' => $request->get('id'),
            ]
        ]);
        $response = $response->getBody()->getContents();
        return $response;
    }
}
